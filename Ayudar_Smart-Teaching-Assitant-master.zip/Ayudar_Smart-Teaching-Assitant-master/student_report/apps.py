from django.apps import AppConfig


class StudentReportConfig(AppConfig):
    name = 'student_report'
