from django.contrib import admin
from .models import professor_profile,course

# Register your models here.
admin.site.register(professor_profile)
admin.site.register(course)
